package com.example.announcementreader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private val busy = AtomicBoolean(false)
    private var lastText = ""
    private var candidateText = ""
    private var candidateCount = 0
    private var lastTypedAt = 0L
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") (intent?.getParcelableExtra("data") as? Intent)
        if (code == 0 || data == null) { stopSelf(); return START_NOT_STICKY }

        val thread = HandlerThread("announcement-ocr").apply { start() }
        worker = Handler(thread.looper)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        display = projection?.createVirtualDisplay(
            "AnnouncementReader", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, worker
        )
        reader?.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!busy.compareAndSet(false, true)) { image.close(); return@setOnImageAvailableListener }
            processImage(image, width, height)
        }, worker)
        return START_STICKY
    }

    private fun processImage(image: Image, width: Int, height: Int) {
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            // Screenshot reference places the white scrolling banner around 20%-27%
            // of screen height. Keep this narrow to avoid the large center announcement.
            val top = (height * 0.18f).toInt()
            val bottom = (height * 0.29f).toInt()
            val crop = Bitmap.createBitmap(bitmap, 0, top, width, (bottom - top).coerceAtLeast(1))

            // Keep only bright, low-saturation pixels (the banner's white lettering).
            // Convert them to dark glyphs on a light background for OCR.
            val pixels = IntArray(crop.width * crop.height)
            crop.getPixels(pixels, 0, crop.width, 0, 0, crop.width, crop.height)
            for (i in pixels.indices) {
                val c = pixels[i]
                val red = android.graphics.Color.red(c)
                val green = android.graphics.Color.green(c)
                val blue = android.graphics.Color.blue(c)
                val brightest = maxOf(red, green, blue)
                val darkest = minOf(red, green, blue)
                val isWhiteText = brightest >= 190 && (brightest - darkest) <= 55
                pixels[i] = if (isWhiteText) android.graphics.Color.BLACK else android.graphics.Color.WHITE
            }
            crop.setPixels(pixels, 0, crop.width, 0, 0, crop.width, crop.height)

            recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener { result ->
                    val text = result.text.replace("\\n", " ").replace(Regex("\\\\s+"), " ").trim()
                    // Ignore tiny fragments and require the same OCR result in consecutive
                    // frames before typing, reducing partial reads while the banner scrolls.
                    if (text.length >= 8 && text.any { it.isLetter() }) {
                        if (text == candidateText) candidateCount++ else {
                            candidateText = text
                            candidateCount = 1
                        }
                        val now = System.currentTimeMillis()
                        if (candidateCount >= 2 && text != lastText && now - lastTypedAt > 2500) {
                            val ok = AutoTypeAccessibilityService.instance?.typeIntoFocusedField(text) ?: false
                            if (ok) {
                                lastText = text
                                lastTypedAt = now
                            }
                        }
                    } else {
                        candidateText = ""
                        candidateCount = 0
                    }
                }
                .addOnCompleteListener {
                    crop.recycle(); bitmap.recycle(); busy.set(false)
                }
        } catch (_: Exception) {
            try { image.close() } catch (_: Exception) {}
            busy.set(false)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun createNotification() {
        val channelId = "announcement_reader"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Announcement Reader", NotificationManager.IMPORTANCE_LOW))
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Announcement Reader is running")
            .setContentText("Screen text recognition is active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
        startForeground(7, notification)
    }

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
