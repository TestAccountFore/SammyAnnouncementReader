# Sammy Announcement Reader (Android Studio source)

This is a starter Android Studio project for Android 10+.

## What it does
- Uses Android's screen-capture consent dialog (MediaProjection).
- Runs on-device ML Kit OCR over a configurable upper-screen band (8%–34%).
- If an editable field is currently focused and the Android accessibility service is enabled, it attempts to replace that field's contents with newly recognized text.

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support).
2. Let Gradle sync and build.
3. Install on your Android phone.
4. Open the app, enable its accessibility service in Android Settings, then return and tap Start.
5. Approve Android's screen-sharing prompt.
6. Switch to Roblox. When you want text entered, focus the destination text field first.

## Important limitations / safety
- This is NOT a Roblox executor script and does not inject code into Roblox.
- Android requires visible screen-capture consent and accessibility permission.
- Android accessibility APIs can only set text in fields exposed as editable accessibility nodes. Roblox's in-game chat or custom UI may not expose such a node, so typing may fail there.
- OCR may read partial scrolling announcements, other UI text in the crop, or duplicate text. The crop coordinates may need adjustment for your device.
- This starter version types the recognized OCR result into the focused field; it does not submit/send it.
- Use only where you have authorization. Do not use it to spam chat or disrupt other players.
- For reliable use, test first in a harmless text field such as a notes app.


## Announcement-area filtering update
The OCR pass now crops a narrower band (18%–29% of screen height) based on the supplied screenshot and filters for bright, low-saturation/white pixels before recognition. It requires the same OCR result in consecutive frames before attempting to type it. This is a heuristic, not guaranteed sender identification: any sufficiently bright text inside that band may still be read. If the banner appears at a different vertical position on your device, the crop percentages in `ScreenCaptureService.kt` may need adjustment.
